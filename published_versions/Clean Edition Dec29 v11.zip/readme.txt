Final Fantasy V/5r Clean Edition v1.1

Hello, this patch brings together some UI/UX improvements and adjusts some icons to make for a cleaner FFV and FF5r experience.

Two patches are included: choose the correct one for your rom, apply, and enjoy the enhanced menus (and in FFV, more fluid battles closer to FFVI)!

Interface adjustments
FFV
- L & R buttons scroll in Item Menu
- L & R buttons swap between characters in Status & Equip menus
- X button skips to next active character in battle

FF5r
- L & R buttons scroll in Item Menu
- L & R buttons swap between characters in Status & Equip menus
- (Skip in battle not done to respect FF5r difficulty curve)

Magic adjustments
- Blue Magic spells now have diamond icons (🔷)
- Mystery spell ???? now Revenge (in FFV)
- Summon Magic spells now have category icons (⚫️⚪️🕒)

Weapon adjustments
- Boomerang icon from FFIV for 2 weapons: Full Moon, RisinSun
- Whip icon used for: Flail, MornStar
- Shuriken icon used for all throwable items (scrolls of Flame, Water, Thunder + Soot item)
- Pinwheel => Fuma

Job System, Script adjustments
- Red Mage => RedMage
- Dimen => Time
- DmMgc => Time
- ”Dimensional Magic” => “Time Magic”

With opensource content from
- https://www.romhacking.net/translations/353/
- https://www.romhacking.net/hacks/1408/
- https://www.romhacking.net/hacks/7972/
- https://www.romhacking.net/hacks/6818/
- https://www.romhacking.net/hacks/7972/
- http://x11.s11.xrea.com/ff5patches

Thanks to Inu, Tzepish, Samurai Goroh, madsiur, Nintenja for patches, tools, guides, and inspiration!
Thanks to s8fp98fd5k for “FF5r” and to Serenity for its English translation!
Thanks to Squaresoft for Final Fantasy V!

Main patch MAY work with other versions (GBA Script, Spoof) but has not been rigorously tested on these. FF5r patch is designed only for the English version of that hack– gomen nasai.

Changes in v1.1
- Added spear icon to weapon  𐃆TwnLance, removing final “Misc.” occurence
- Changed Full Moon to FullMoon
- Added more patches to (attempt to) remove item handling glitches.